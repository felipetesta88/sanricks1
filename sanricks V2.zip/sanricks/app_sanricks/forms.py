from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm , UserChangeForm, AuthenticationForm
from .models import Producto, Categoria, Marca,UserCustom ,UserProfile
from django.contrib.auth import authenticate
from django.core.exceptions import ValidationError


# Formulario de registro de usuario
class CustomUserCreationForm(UserCreationForm):
    # Campos adicionales del perfil de usuario
    telefono = forms.CharField(required=False, max_length=15, label="Teléfono")
    direccion = forms.CharField(required=False, max_length=255, label="Dirección")
    ciudad = forms.CharField(required=False, max_length=100, label="Ciudad")

    class Meta:
        model = UserCustom
        fields = ('email', 'nombre', 'password1', 'password2')  # Campos principales de UserCustom

    def save(self, commit=True):
        user = super().save(commit=False)
        if commit:
            user.save()
            # Crear perfil de usuario con los datos adicionales
            UserProfile.objects.create(
                usuario=user,
                telefono=self.cleaned_data.get('telefono'),
                direccion=self.cleaned_data.get('direccion'),
                ciudad=self.cleaned_data.get('ciudad'),
            )
        return user


class CustomUserChangeForm(UserChangeForm):
    # Este formulario se usa en el admin para actualizar usuarios
    class Meta:
        model = UserCustom
        fields = ('id_usuario', 'email', 'nombre', 'is_active', 'is_staff')


class UserProfileForm(forms.ModelForm):
    # Formulario para actualizar el perfil de usuario
    class Meta:
        model = UserProfile
        fields = ('telefono', 'direccion', 'ciudad', 'email')  # Campos que se pueden actualizar en el perfil

    # Opción para personalizar la apariencia o etiquetas de los campos (opcional)
    telefono = forms.CharField(required=False, max_length=15, label="Teléfono")
    direccion = forms.CharField(required=False, max_length=255, label="Dirección")
    ciudad = forms.CharField(required=False, max_length=100, label="Ciudad")
    email = forms.EmailField(required=False, label="Correo electrónico")

# Formulario para actualizar la cantidad de productos en el carrito (AJAX)
class ActualizarCantidadForm(forms.Form):
    cantidad = forms.IntegerField(min_value=1, required=True)

    def __init__(self, *args, **kwargs):
        # Recibimos el objeto 'producto' para validarlo en la cantidad
        self.producto = kwargs.pop('producto', None)
        super().__init__(*args, **kwargs)

    def clean_cantidad(self):
        cantidad = self.cleaned_data.get('cantidad')
        if cantidad < 1:
            raise forms.ValidationError("La cantidad debe ser al menos 1.")
        if self.producto and cantidad > self.producto.stock:
            raise forms.ValidationError(f"Solo hay {self.producto.stock} unidades disponibles.")
        return cantidad

# Formulario de producto (para agregar un nuevo producto)
class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['nombre', 'descripcion', 'precio', 'stock', 'categoria', 'marca', 'imagen']  # Incluye marca si la tienes
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 4}),
        }

    imagen = forms.ImageField(required=False)  # Si se permite subir imágenes

    # Si usas marcas:
    marca = forms.ModelChoiceField(queryset=Marca.objects.all())

    def clean_nombre(self):
        nombre = self.cleaned_data.get('nombre')
        if Producto.objects.filter(nombre=nombre).exists():
            raise forms.ValidationError("Este nombre de producto ya está registrado.")
        return nombre

    def clean_precio(self):
        precio = self.cleaned_data.get('precio')
        if precio <= 0:
            raise forms.ValidationError("El precio debe ser mayor que 0.")
        return precio

class CustomAuthenticationForm(forms.Form):
    email = forms.EmailField(label='Correo electrónico', max_length=255)
    password = forms.CharField(label='Contraseña', widget=forms.PasswordInput)

    def clean(self):
        email = self.cleaned_data.get('email')
        password = self.cleaned_data.get('password')

        user = authenticate(email=email, password=password)
        if not user:
            raise forms.ValidationError('Correo o contraseña incorrectos')
        return self.cleaned_data