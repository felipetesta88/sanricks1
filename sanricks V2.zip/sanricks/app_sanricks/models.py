from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

# Manager personalizado para el modelo UserCustom
class CustomUserManager(BaseUserManager):
    def create_user(self, id_usuario, email, password=None, **extra_fields):
        if not id_usuario:
            raise ValueError("El usuario debe tener un ID")
        if not email:
            raise ValueError("El usuario debe tener un correo electrónico")

        email = self.normalize_email(email)
        user = self.model(id_usuario=id_usuario, email=email, **extra_fields)
        if password:
            user.password = password  # Aquí asignamos la contraseña directamente, sin cifrar
        user.save(using=self._db)
        return user

    def create_superuser(self, id_usuario, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError("El superusuario debe tener is_staff=True.")
        if extra_fields.get('is_superuser') is not True:
            raise ValueError("El superusuario debe tener is_superuser=True.")

        return self.create_user(id_usuario, email, password, **extra_fields)

# Modelo de usuario personalizado
class UserCustom(AbstractBaseUser):
    id_usuario = models.BigAutoField(primary_key=True) 
    email = models.EmailField(unique=True)
    nombre = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    objects = CustomUserManager()

    USERNAME_FIELD = 'id_usuario'
    REQUIRED_FIELDS = ['email']

    def __str__(self):
        return self.id_usuario

    def set_password(self, raw_password):
        # Almacenamos la contraseña tal cual, sin cifrar
        self.password = raw_password

    # Sobrescribir el método check_password
    def check_password(self, raw_password):
        # Compara las contraseñas sin cifrado
        return self.password == raw_password

# Modelo de perfil de usuario actualizado
class UserProfile(models.Model):
    usuario = models.OneToOneField(UserCustom, on_delete=models.CASCADE)
    telefono = models.CharField(max_length=15, blank=True, null=True)
    direccion = models.CharField(max_length=255, blank=True, null=True)
    ciudad = models.CharField(max_length=100, blank=True, null=True)
    email = models.EmailField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f"Perfil de {self.usuario.id_usuario}"

# Categoría de producto
class Categoria(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

# Marca de producto
class Marca(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre    

# Producto con categoría y marca
class Producto(models.Model):
    nombre = models.CharField(max_length=200)
    descripcion = models.TextField()
    precio = models.DecimalField(max_digits=10, decimal_places=0)
    stock = models.PositiveIntegerField()
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    marca = models.ForeignKey(Marca, on_delete=models.SET_NULL, null=True, default=1)
    imagen = models.ImageField(upload_to='productos/', blank=True, null=True)

    def __str__(self):
        return self.nombre    

# Adaptación de modelos relacionados con el usuario
class Carrito(models.Model):
    usuario = models.ForeignKey(UserCustom, on_delete=models.CASCADE)
    creado_en = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Carrito de {self.usuario.id_usuario}"

#Elementos en el carrito de compras
class CarritoItem(models.Model):
    carrito = models.ForeignKey(Carrito, on_delete=models.CASCADE, related_name='items')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.cantidad} x {self.producto.nombre} en {self.carrito}"

    @property
    def total_precio(self):
        return self.cantidad * self.producto.precio    

class Orden(models.Model):
    usuario = models.ForeignKey(UserCustom, on_delete=models.CASCADE)
    carrito = models.OneToOneField(Carrito, on_delete=models.CASCADE)
    total = models.DecimalField(max_digits=10, decimal_places=2)
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)
    ESTADOS = [
        ('pendiente', 'Pendiente'),
        ('procesando', 'Procesando'),
        ('enviado', 'Enviado'),
        ('completado', 'Completado'),
        ('cancelado', 'Cancelado'),
    ]
    estado = models.CharField(max_length=20, choices=ESTADOS, default='pendiente')

    def __str__(self):
        return f"Orden #{self.id} - {self.usuario.id_usuario} - {self.estado}"

class DireccionEnvio(models.Model):
    usuario = models.ForeignKey(UserCustom, on_delete=models.CASCADE)
    orden = models.ForeignKey(Orden, on_delete=models.CASCADE, related_name='direccion_envio')
    direccion = models.CharField(max_length=255)
    ciudad = models.CharField(max_length=100)
    region = models.CharField(max_length=100)
    codigo_postal = models.CharField(max_length=10)
    pais = models.CharField(max_length=100)

    def __str__(self):
        return f"Dirección de {self.usuario.id_usuario} para la Orden #{self.orden.id}"
