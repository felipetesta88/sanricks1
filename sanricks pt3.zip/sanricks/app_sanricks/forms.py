from django import forms
from .models import Producto, Categoria, Marca, Entrega




# Formulario para actualizar la cantidad de productos en el carrito (AJAX)
class ActualizarCantidadForm(forms.Form):
    cantidad = forms.IntegerField(min_value=1, required=True)

    def __init__(self, *args, **kwargs):
        # Recibimos el objeto 'producto' para validarlo en la cantidad
        self.producto = kwargs.pop('producto', None)
        super().__init__(*args, **kwargs)

    def clean_cantidad(self):
        cantidad = self.cleaned_data.get('cantidad')
        if cantidad < 1:
            raise forms.ValidationError("La cantidad debe ser al menos 1.")
        if self.producto and cantidad > self.producto.stock:
            raise forms.ValidationError(f"Solo hay {self.producto.stock} unidades disponibles.")
        return cantidad

# Formulario de producto (para agregar un nuevo producto)
class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['nombre', 'descripcion', 'precio', 'stock', 'categoria', 'marca', 'imagen']  # Incluye marca si la tienes
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 4}),
        }

    imagen = forms.ImageField(required=False)  # Si se permite subir imágenes

    # Si usas marcas:
    marca = forms.ModelChoiceField(queryset=Marca.objects.all())

    def clean_nombre(self):
        nombre = self.cleaned_data.get('nombre')
        if Producto.objects.filter(nombre=nombre).exists():
            raise forms.ValidationError("Este nombre de producto ya está registrado.")
        return nombre

    def clean_precio(self):
        precio = self.cleaned_data.get('precio')
        if precio <= 0:
            raise forms.ValidationError("El precio debe ser mayor que 0.")
        return precio

class EntregaForm(forms.ModelForm):
    class Meta:
        model = Entrega
        fields = ['nombre', 'rut', 'telefono', 'correo', 'direccion', 'comentario']

    def __init__(self, *args, **kwargs):
        # Sobrescribimos el método __init__ para agregar lógica adicional si es necesario
        super().__init__(*args, **kwargs)
        self.fields['nombre'].widget.attrs.update({'class': 'form-control'})
        self.fields['rut'].widget.attrs.update({'class': 'form-control'})
        self.fields['telefono'].widget.attrs.update({'class': 'form-control'})
        self.fields['correo'].widget.attrs.update({'class': 'form-control'})
        self.fields['direccion'].widget.attrs.update({'class': 'form-control'})
        self.fields['comentario'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Opcional'})