from django.db import models

# Categoría de producto
class Categoria(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

# Marca de producto
class Marca(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre    

# Producto con categoría y marca
class Producto(models.Model):
    nombre = models.CharField(max_length=200)
    descripcion = models.TextField()
    precio = models.DecimalField(max_digits=10, decimal_places=0)
    stock = models.PositiveIntegerField()
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    marca = models.ForeignKey(Marca, on_delete=models.SET_NULL, null=True, default=1)
    imagen = models.ImageField(upload_to='productos/', blank=True, null=True)

    def __str__(self):
        return self.nombre    

# Adaptación de modelos relacionados con el usuario
class Carrito(models.Model):
    ESTADOS = [
        ('activo', 'Activo'),
        ('finalizado', 'Finalizado'),
        ('abandonado', 'Abandonado'),
    ]
    session_key = models.CharField(max_length=40, blank=True, null=True)  # Usar session_key para carritos anónimos
    estado = models.CharField(max_length=20, choices=ESTADOS, default='activo')
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    metodo_pago = models.CharField(max_length=20, choices=[
        ('tarjeta', 'Tarjeta de Crédito'),
        ('paypal', 'PayPal'),
        ('efectivo', 'Efectivo'),
    ], null=True, blank=True)
    fecha_expiracion = models.DateTimeField(null=True, blank=True)
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Carrito (ID de sesión: {self.session_key}) - Estado: {self.estado}"
#Elementos en el carrito de compras
class CarritoItem(models.Model):
    carrito = models.ForeignKey(Carrito, on_delete=models.CASCADE, related_name='items')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    total_precio = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.cantidad} x {self.producto.nombre} en {self.carrito}"

    @property
    def total_precio(self):
        return self.cantidad * self.producto.precio    

class Orden(models.Model):
    carrito = models.OneToOneField(Carrito, on_delete=models.CASCADE)
    total = models.DecimalField(max_digits=10, decimal_places=2)
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)
    ESTADOS = [
        ('pendiente', 'Pendiente'),
        ('procesando', 'Procesando'),
        ('enviado', 'Enviado'),
        ('completado', 'Completado'),
        ('cancelado', 'Cancelado'),
    ]
    estado = models.CharField(max_length=20, choices=ESTADOS, default='pendiente')

    def __str__(self):
        return f"Orden #{self.id} - del Cliente - {self.estado}"

class DireccionEnvio(models.Model):
    orden = models.ForeignKey(Orden, on_delete=models.CASCADE, related_name='direccion_envio')
    direccion = models.CharField(max_length=255)
    ciudad = models.CharField(max_length=100)
    region = models.CharField(max_length=100)
    codigo_postal = models.CharField(max_length=10)
    pais = models.CharField(max_length=100)

    def __str__(self):
        return f"Dirección de  para la Orden #{self.orden.id}"
    
class Entrega(models.Model):
    nombre = models.CharField(max_length=100)
    rut = models.CharField(max_length=12)
    telefono = models.CharField(max_length=15)
    correo = models.EmailField()
    direccion = models.TextField()
    comentario = models.TextField(blank=True, null=True)
    carrito = models.OneToOneField(Carrito, on_delete=models.CASCADE)  # Relación directa con un carrito
    productos = models.TextField(editable=False)  # Lista de productos generada automáticamente
    precio_total = models.DecimalField(max_digits=10, decimal_places=2, editable=False)  # Calculado automáticamente
    fecha_entrega = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        # Calcular productos y precio total a partir del carrito
        items = self.carrito.items.all()
        self.productos = "\n".join(
            [f"{item.cantidad}x {item.producto.nombre}" for item in items]
        )
        self.precio_total = sum(item.total_precio for item in items)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Entrega de {self.nombre} - {self.fecha_entrega.strftime('%Y-%m-%d %H:%M')}"