from django.contrib import admin
from .models import Categoria, Producto, Marca  # Asegúrate de incluir Marca si deseas

admin.site.register(Categoria)  # Agregar la clase Categoria al admin
admin.site.register(Producto)    # Agregar la clase Producto al admin
admin.site.register(Marca) 

# Register your models here.
