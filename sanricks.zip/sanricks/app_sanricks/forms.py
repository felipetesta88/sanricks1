from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Producto, Categoria, Marca

# Formulario de registro de usuario
class RegistroForm(UserCreationForm):
    email = forms.EmailField(required=True, help_text="Requerido. Introduce una dirección de correo electrónico válida.")

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("Este correo electrónico ya está registrado.")
        return email

# Formulario para actualizar la cantidad de productos en el carrito (AJAX)
class ActualizarCantidadForm(forms.Form):
    cantidad = forms.IntegerField(min_value=1, required=True)

    def clean_cantidad(self):
        cantidad = self.cleaned_data.get('cantidad')
        if cantidad < 1:
            raise forms.ValidationError("La cantidad debe ser al menos 1.")
        return cantidad

class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['nombre', 'descripcion', 'precio', 'stock', 'categoria']  # Incluye marca si la tienes
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 4}),
        }
    
    # Si usas marcas:
    marca = forms.ModelChoiceField(queryset=Marca.objects.all())
