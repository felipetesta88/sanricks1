from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from app_sanricks.models import Producto, Carrito, Categoria, Marca
from django.http import JsonResponse
from django.contrib.auth.forms import AuthenticationForm
from .forms import RegistroForm
from .forms import ProductoForm
from .models import Categoria, Marca
from django.db.models import Q 

from django.conf import settings
from django.core.paginator import Paginator


from django.shortcuts import render
from django.contrib import messages
import random


def recuperar_contrasena(request):
    if request.method == 'POST':
        # Obtener el email del formulario (aunque no se verifique su existencia en este caso)
        email = request.POST.get('email')
        
        # Mensaje básico independientemente de si el usuario existe o no
        messages.success(request, 'Hemos enviado su solicitud, espere instrucciones para cambiar usuario y/o contraseña.')
    
    # Renderizar el formulario de recuperación de contraseña
    return render(request, 'app_sanricks/recuperar_contrasena.html')




# Vista para la página de inicio (listado de productos)
def inicio(request):
    categorias = Categoria.objects.all()  # Obtiene todas las categorías
    marcas = Marca.objects.all()  # Obtiene todas las marcas

    # Obtener el ID de categoría y marca desde la solicitud
    categoria_id = request.GET.get('categoria')
    marca_id = request.GET.get('marca')

    # Filtrar productos según los parámetros
    productos = Producto.objects.all()  # Obtiene todos los productos inicialmente

    if categoria_id:
        productos = productos.filter(categoria_id=categoria_id)

    if marca_id:
        productos = productos.filter(marca_id=marca_id)

    paginator = Paginator(productos, 12)  # Configura 12 productos por página

    page_number = request.GET.get('page')  # Obtén el número de la página actual desde la URL
    page_obj = paginator.get_page(page_number)

    contexto = {
        'page_obj': page_obj,
        'categorias': categorias,
        'marcas': marcas,
        'MEDIA_URL': settings.MEDIA_URL,
    }

    return render(request, 'app_sanricks/index.html', contexto)



# Vista para el detalle de cada producto
def producto_detalle(request, id):
    producto = get_object_or_404(Producto, id=id)
    
    # Filtrar productos relacionados por categoría o marca
    productos_relacionados = Producto.objects.filter(
        Q(categoria=producto.categoria) | Q(marca=producto.marca)
    ).exclude(id=producto.id)  # Excluye el producto actual

    # Aleatorizar los resultados y limitar a 2
    productos_relacionados = productos_relacionados.order_by('?')[:2]

    contexto = {
        'producto': producto,
        'productos_relacionados': productos_relacionados,
    }
    
    return render(request, 'app_sanricks/producto_detalle.html', contexto)




# Vista para manejar el registro de usuario
def registro(request):
    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Cuenta creada exitosamente')
            return redirect('inicio')
    else:
        form = RegistroForm()
    return render(request, 'registro.html', {'form': form})

# Vista para manejar el inicio de sesión
def iniciar_sesion(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('inicio')
            else:
                messages.error(request, 'Usuario o contraseña incorrectos')
        else:
            messages.error(request, 'Usuario o contraseña incorrectos')
    form = AuthenticationForm()
    return render(request, 'app_sanricks/inicio_seccion.html', {'form': form})

# Vista para manejar el cierre de sesión
def cerrar_sesion(request):
    logout(request)
    return redirect('inicio')

# Vista para agregar un producto al carrito
@login_required
def agregar_al_carrito(request, producto_id):
    producto = get_object_or_404(Producto, id=id)
    carrito, created = Carrito.objects.get_or_create(user=request.user, producto=producto)
    carrito.cantidad += 1
    carrito.save()
    messages.success(request, 'Producto agregado al carrito')
    return redirect('inicio')

# Vista para mostrar el carrito del usuario
@login_required
def ver_carrito(request):
    carrito_items = Carrito.objects.filter(user=request.user)
    total = sum(item.producto.precio * item.cantidad for item in carrito_items)
    contexto = {
        'carrito_items': carrito_items,
        'total': total,
    }
    return render(request, 'carrito.html', contexto)

# Vista para eliminar un producto del carrito
@login_required
def eliminar_del_carrito(request, id):
    item = get_object_or_404(Carrito, id=id, user=request.user)
    item.delete()
    messages.success(request, 'Producto eliminado del carrito')
    return redirect('ver_carrito')

# Vista para actualizar la cantidad de un producto en el carrito (AJAX)
@login_required
def actualizar_cantidad(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        cantidad = request.POST.get('cantidad')
        item = get_object_or_404(Carrito, id=item_id, user=request.user)
        item.cantidad = cantidad
        item.save()
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'failed'})

# Vista para realizar la compra (Checkout)
@login_required
def checkout(request):
    carrito_items = Carrito.objects.filter(user=request.user)
    total = sum(item.producto.precio * item.cantidad for item in carrito_items)
    if request.method == 'POST':
        # Lógica de compra aquí (guardar pedido, limpiar carrito, etc.)
        carrito_items.delete()
        messages.success(request, 'Compra realizada con éxito')
        return redirect('inicio')
    contexto = {
        'carrito_items': carrito_items,
        'total': total,
    }
    return render(request, 'checkout.html', contexto)


def agregar_producto(request):
    if request.method == "POST":
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inicio')  # Redirige a la página principal o donde desees
    else:
        form = ProductoForm()
    
    return render(request, 'app_sanricks/agregar_producto.html', {'form': form})

def producto_list(request):
    productos = Producto.objects.all()  # Obtener todos los productos
    paginator = Paginator(productos, 12)  # Mostrar 12 productos por página

    page_number = request.GET.get('page')  # Obtener el número de página desde la URL
    page_obj = paginator.get_page(page_number)  # Obtener el objeto de la página
    return render(request, 'app_sanricks/index.html', {'page_obj': page_obj})


def buscar_producto(request):
    query = request.GET.get('q')
    productos = Producto.objects.filter(nombre__icontains=query)
    return render(request, 'app_sanricks/resultados_busqueda.html', {'productos': productos, 'query': query})

@login_required
def mi_cuenta(request):
    # Aquí puedes obtener información adicional del usuario si es necesario.
    return render(request, 'app_sanricks/mi_cuenta.html')