from django.contrib import admin
from django.urls import path, include
from app_sanricks import views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static
from app_sanricks.views import recuperar_contrasena


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.iniciar_sesion, name='inicio'),
    path('recuperar_contrasena/', recuperar_contrasena, name='recuperar_contrasena'),
    path('producto/<int:id>/', views.producto_detalle, name='producto_detalle'),
    path('registro/', views.registro, name='registro'),
    path('buscar/', views.buscar_producto, name='buscar_producto'),
    path('index/', views.inicio, name='index'),
    path('logout/', views.cerrar_sesion, name='logout'),
    path('mi_cuenta/', views.mi_cuenta, name='mi_cuenta'),
    path('agregar-al-carrito/<int:id>/', views.agregar_al_carrito, name='agregar_al_carrito'),
    path('carrito/', views.ver_carrito, name='ver_carrito'),
    path('eliminar-del-carrito/<int:id>/', views.eliminar_del_carrito, name='eliminar_del_carrito'),
    path('actualizar-cantidad/', views.actualizar_cantidad, name='actualizar_cantidad'),
    path('checkout/', views.checkout, name='checkout'),
    path('agregar-producto/', views.agregar_producto, name='agregar_producto'),
    path('reset_password/', auth_views.PasswordResetView.as_view(template_name="password_reset.html"), name="password_reset"),
    path('reset_password_sent/', auth_views.PasswordResetDoneView.as_view(template_name="password_reset_sent.html"), name="password_reset_done"),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name="password_reset_form.html"), name="password_reset_confirm"),
    path('reset_password_complete/', auth_views.PasswordResetCompleteView.as_view(template_name="password_reset_done.html"), name="password_reset_complete"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
