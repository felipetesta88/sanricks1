from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from app_sanricks.models import Producto, Carrito, Categoria, Marca, CarritoItem, Entrega
from django.http import JsonResponse
from .forms import ProductoForm, EntregaForm
from .models import Categoria, Marca
from django.db.models import Q 
from django.conf import settings
from django.core.paginator import Paginator
from django.contrib import messages
from django.http import Http404
import mercadopago



# Vista para la página de inicio (listado de productos)

def inicio(request):
    categorias = Categoria.objects.all()  # Obtiene todas las categorías
    marcas = Marca.objects.all()  # Obtiene todas las marcas

    # Obtener el ID de categoría y marca desde la solicitud
    categoria_id = request.GET.get('categoria')
    marca_id = request.GET.get('marca')

    # Filtrar productos según los parámetros
    productos = Producto.objects.all().order_by('nombre')  # Obtiene todos los productos inicialmente

    if categoria_id:
        productos = productos.filter(categoria_id=categoria_id)

    if marca_id:
        productos = productos.filter(marca_id=marca_id)

    paginator = Paginator(productos, 12)  # Configura 12 productos por página

    page_number = request.GET.get('page')  # Obtén el número de la página actual desde la URL
    page_obj = paginator.get_page(page_number)

    contexto = {
        'page_obj': page_obj,
        'categorias': categorias,
        'marcas': marcas,
        'MEDIA_URL': settings.MEDIA_URL,
    }

    return render(request, 'app_sanricks/index.html', contexto)



# Vista para el detalle de cada producto
def producto_detalle(request, id):
    producto = get_object_or_404(Producto, id=id)
    
    # Filtrar productos relacionados por categoría o marca
    productos_relacionados = Producto.objects.filter(
        Q(categoria=producto.categoria) | Q(marca=producto.marca)
    ).exclude(id=producto.id)  # Excluye el producto actual

    # Aleatorizar los resultados y limitar a 2
    productos_relacionados = productos_relacionados.order_by('?')[:2]

    contexto = {
        'producto': producto,
        'productos_relacionados': productos_relacionados,
    }
    
    return render(request, 'app_sanricks/producto_detalle.html', contexto)


# Vista para agregar un producto al carrito

def agregar_al_carrito(request, id):
    producto = get_object_or_404(Producto, id=id)
    cantidad = int(request.POST.get('cantidad', 1))  # Obtener la cantidad del formulario

    # Obtener el carrito de la sesión usando session_key
    session_key = request.session.session_key
    if not session_key:
        request.session.create()  # Crear una nueva sesión si no existe
        session_key = request.session.session_key

    # Verificar si el carrito existe, si no, crear uno nuevo
    carrito, creado = Carrito.objects.get_or_create(session_key=session_key)
    
    # Verificar si el producto ya está en el carrito
    item, creado = CarritoItem.objects.get_or_create(carrito=carrito, producto=producto)

    if not creado:
        # Si ya existe, solo actualiza la cantidad
        item.cantidad += cantidad
    else:
        # Si no existe, establece la cantidad inicial
        item.cantidad = cantidad

    item.save()

    # Actualizar el stock del producto
    if producto.stock >= cantidad:
        producto.stock -= cantidad
        producto.save()
    else:
        messages.error(request, "No hay suficiente stock disponible.")
        return redirect('producto_detalle', id=id)

    messages.success(request, f"{producto.nombre} agregado al carrito.")
    return redirect('producto_detalle', id=id)


# Vista para mostrar el carrito del usuario

def ver_carrito(request):
    # Obtener el carrito de la sesión usando session_key
    session_key = request.session.session_key
    if not session_key:
        request.session.create()  # Crear una nueva sesión si no existe
        session_key = request.session.session_key

    # Obtener el carrito asociado con la session_key
    print("Carrito no encontrado, creandolo ahora.")
    carrito = Carrito.objects.filter(session_key=request.session.session_key).first()
    
    if carrito is None:
        # Si no hay carrito asociado con esa sesión, crear uno nuevo
        carrito = Carrito.objects.create(session_key=request.session.session_key)
    carrito_items=carrito.items.all()
    print(f"Carrito tiene {carrito_items.count()}items.")

    # Obtener los productos en el carrito
    carrito_items = CarritoItem.objects.filter(carrito=carrito)  # CarritoItem relacionado con este carrito
    print(f"Carrito tiene{carrito_items.count()} items")
    total_precio = sum(item.total_precio for item in carrito_items)
    print(f"Total del carrito:{total_precio}")

    

    # Si no es AJAX, retornar el carrito completo con los datos de los productos
    contexto = {
        'carrito_items': carrito_items,
        'total_precio': total_precio,
        'carrito_id': carrito.id,
    }
    return render(request, 'app_sanricks/carrito.html', contexto)

# Vista para eliminar un producto del carrito

def eliminar_del_carrito(request, id):
    # Asegúrate de que el carrito esté asociado con el session_key
    carrito = Carrito.objects.filter(session_key=request.session.session_key).first()

    if not carrito:
        print("Carrito no encontrado para la sesión.")
        return redirect('ver_carrito')  # O redirige a donde consideres

    # Encuentra el CarritoItem que deseas eliminar
    carrito_item = get_object_or_404(CarritoItem, id=id, carrito=carrito)

    # Elimina el CarritoItem
    carrito_item.delete()

    # Redirige de nuevo al carrito después de eliminar el producto
    return redirect('ver_carrito')

# Vista para actualizar la cantidad de un producto en el carrito (AJAX)
def actualizar_cantidad(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        cantidad = request.POST.get('cantidad')
        item = get_object_or_404(Carrito, id=id)
        item.cantidad = cantidad
        item.save()
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'failed'})

# Vista para realizar la compra (Checkout)

def checkout(request):
    carrito_items = Carrito.objects.filter(Carrito=Carrito)
    total = sum(item.producto.precio * item.cantidad for item in carrito_items)
    if request.method == 'POST':
        # Lógica de compra aquí (guardar pedido, limpiar carrito, etc.)
        carrito_items.delete()
        messages.success(request, 'Compra realizada con éxito')
        return redirect('inicio')
    contexto = {
        'carrito_items': carrito_items,
        'total': total,
    }
    return render(request, 'checkout.html', contexto)


def agregar_producto(request):
    if request.method == "POST":
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inicio')  # Redirige a la página principal o donde desees
    else:
        form = ProductoForm()
    
    return render(request, 'app_sanricks/agregar_producto.html', {'form': form})

def producto_list(request):
    productos = Producto.objects.all()  # Obtener todos los productos
    paginator = Paginator(productos, 12)  # Mostrar 12 productos por página

    page_number = request.GET.get('page')  # Obtener el número de página desde la URL
    page_obj = paginator.get_page(page_number)  # Obtener el objeto de la página
    return render(request, 'app_sanricks/index.html', {'page_obj': page_obj})


def buscar_producto(request):
    query = request.GET.get('q')
    productos = Producto.objects.filter(nombre__icontains=query)
    return render(request, 'app_sanricks/resultados_busqueda.html', {'productos': productos, 'query': query})


def crear_entrega(request, carrito_id):
    try:
        # Obtener el carrito correspondiente
        carrito = Carrito.objects.get(id=carrito_id, estado='activo')
    except Carrito.DoesNotExist:
        raise Http404("Carrito no encontrado o no está activo")
    
    carrito_items = carrito.items.all()  # Asume que Carrito tiene una relación con CarritoItem
    total_precio = sum(item.total_precio for item in carrito_items)

    if request.method == 'POST':
        # Si el formulario es enviado, lo procesamos
        form = EntregaForm(request.POST)
        if form.is_valid():
            # Asocia el carrito a la entrega
            entrega = form.save(commit=False)
            entrega.carrito = carrito  # Asocia el carrito a la entrega
            entrega.save()  # Guarda la entrega, calculando productos y precio automáticamente
            return redirect('entrega_confirmacion', entrega_id=entrega.id) # Redirigir a una vista de confirmación
    else:
        # Si no es un POST, mostramos el formulario vacío
        form = EntregaForm()
    
    context = {
        'form': form,
        'carrito_items': carrito_items,
        'total_precio': total_precio,
    }

    return render(request, 'app_sanricks/crear_entrega.html', context)

def entrega_confirmacion(request, entrega_id):
    try:
        entrega = Entrega.objects.get(id=entrega_id)
    except Entrega.DoesNotExist:
        raise Http404("Entrega no encontrada")
    return render(request, 'app_sanricks/entrega_confirmacion.html', {'entrega': entrega})

def crear_preferencia_pago(request, carrito_id):
    carrito = Carrito.objects.get(id=carrito_id)

    # Crear una preferencia con los productos del carrito
    sdk = mercadopago.SDK(settings.MERCADOPAGO_ACCESS_TOKEN)
    items = [
        {
            "title": item.producto.nombre,
            "quantity": item.cantidad,
            "unit_price": float(item.producto.precio),
            "currency_id": "CLP",  # Cambia según tu país
        }
        for item in carrito.items.all()
    ]

    preference_data = {
        "items": items,
        "payer": {
            "email": "test_user_412428919@testuser.com",  # Correo de prueba
        },
        "back_urls": {
            "success": request.build_absolute_uri("/pago-exitoso/"),
            "failure": request.build_absolute_uri("/pago-fallido/"),
            "pending": request.build_absolute_uri("/pago-pendiente/"),
        },
        "auto_return": "approved",
    }

    preference_response = sdk.preference().create(preference_data)
    preference = preference_response["response"]

    

    # Redirigir al usuario al Sandbox de Mercado Pago
    return redirect(preference["sandbox_init_point"])

def pago_exitoso(request):
    return render(request, "app_sanricks/pago_exitoso.html", {"mensaje": "¡Tu pago se realizó con éxito!"})

def pago_fallido(request):
    return render(request, "app_sanricks/pago_fallido.html", {"mensaje": "El pago no pudo ser procesado. Inténtalo de nuevo."})

def pago_pendiente(request):
    return render(request, "app_sanricks/pago_pendiente.html", {"mensaje": "El pago está pendiente. Por favor verifica más tarde."})





