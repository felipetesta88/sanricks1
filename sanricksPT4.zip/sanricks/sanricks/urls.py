from django.contrib import admin
from django.urls import path
from app_sanricks import views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static



urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.inicio, name='index'),
    path('producto/<int:id>/', views.producto_detalle, name='producto_detalle'),
    path('buscar/', views.buscar_producto, name='buscar_producto'),
    path('agregar_al_carrito/<int:id>/', views.agregar_al_carrito, name='agregar_al_carrito'),
    path('carrito/', views.ver_carrito, name='ver_carrito'),
    path('crear_entrega/<int:carrito_id>/', views.crear_entrega, name='crear_entrega'),
    path('entrega_confirmacion/<int:entrega_id>/', views.entrega_confirmacion, name='entrega_confirmacion'),
    path('eliminar_del_carrito/<int:id>/', views.eliminar_del_carrito, name='eliminar_del_carrito'),
    path('actualizar_cantidad/', views.actualizar_cantidad, name='actualizar_cantidad'),
    path('checkout/', views.checkout, name='checkout'),
    path('agregar_producto/', views.agregar_producto, name='agregar_producto'),
    path('crear-preferencia-pago/<int:carrito_id>/', views.crear_preferencia_pago, name='crear_preferencia_pago'),
    path('pago-exitoso/', views.pago_exitoso, name='pago_exitoso'),
    path('pago-fallido/', views.pago_fallido, name='pago_fallido'),
    path('pago-pendiente/', views.pago_pendiente, name='pago_pendiente'),
    
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
